# VariantPersist
Remembers your choices for default part variants in between play sessions.
(That is, when you select a default variant in the editor by clicking the
little "teardrop" icon on in the parts panel, it remembers your choice so
that the next time you start KSP, you won't have to set it up all over
again every time.)